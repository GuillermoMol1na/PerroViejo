using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class ScriptTMPSortingLayer : MonoBehaviour
{
   public int sortingLayer = 0;
}
