using UnityEngine;

public class Difficulty_Minigame1
{
    private float theTimeEasy= 300;
    private float theTimeMedium = 240;
    private float theTimeHard = 150;
    
    public float EasyTime(){
        return theTimeEasy;
    }
    public float MediumTime(){
        return theTimeMedium;
    }
    public float HardTime(){
        return theTimeHard;
    }

}
